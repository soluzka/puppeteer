const puppeteer = require('puppeteer');

// URL of the page to scrape
const url = 'https://www.windowssearch-exp.com/videos/riverview/relatedvideo';

// Function to scrape the page
async function scrapePage() {
    try {
        // Launch a headless browser
        const browser = await puppeteer.launch();
        const page = await browser.newPage();

        // Navigate to the page
        await page.goto(url, { waitUntil: 'networkidle2' });

        // Extract the desired data
        const videos = await page.evaluate(() => {
            const videoElements = document.querySelectorAll('.video-item');
            const videoData = [];
            videoElements.forEach(video => {
                const title = video.querySelector('h3').innerText;
                const link = video.querySelector('a').href;
                videoData.push({ title, link });
            });
            return videoData;
        });

        // Output the extracted data
        console.log(videos);

        // Close the browser
        await browser.close();
    } catch (error) {
        console.error('Error scraping the page:', error);
    }
}

// Run the scrape function
scrapePage();
